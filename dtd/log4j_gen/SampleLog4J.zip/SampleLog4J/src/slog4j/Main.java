package slog4j;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.XMLLayout;

public class Main {
	private final static Random rnd = new Random(System.currentTimeMillis());
	//private final static String defaultPattern = "%d{ISO8601}: %m%n";
	private final static Logger logger = Logger.getLogger(Main.class);
	private static long line = 100;
	private static String fileName = null;
	private static boolean cdataReplace = false;

	public static void main(String[] args) {
		/**
		 * parse argument
		 */
		ArgumentsParser argParser = new ArgumentsParser();
		argParser.addDefaultAction(a -> 
			argParser.printHelpBeforeExit(System.err, 1)
		)
		.addHelp("h", "help", false, "show this help message", a ->
			argParser.printHelpBeforeExit(System.out, 0)
		)
		.addOption("n", "num", true, "number of generated log (default is 100)", a -> {
			line = Long.parseLong(a.get());
			if(line <= 0) {
				throw new IllegalArgumentException("must be positive integer: " + line);
			}
			System.out.println("expected number: " + line);
		})
		.addOption("o", "output", true, "generated log file name", true, a -> 
			fileName = a.get()
		)
		.addOption("r", "rm-cdata", false, "generate no cdata log too.", a ->
			cdataReplace = true
		);

		try {
			argParser.parseAndInvokeAction(args);
		} catch(IllegalArgumentException e) {
			e.printStackTrace();
			argParser.printHelpBeforeExit(System.err, 1);
		}
		
		/**
		 * invoke log generator
		 */
		try {
			FileAppender appender = new FileAppender(new XMLLayout(), fileName, false);
			appender.setImmediateFlush(true);
			BasicConfigurator.configure(appender);
			for(long i = 0; i < line; i++) {
				if(i == 0) {
					writeRandomLog();
					appender.setAppend(true);
				} else {
					writeRandomLog();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			fatal("cannot open file: " + fileName);
		}

		/**
		 * remove cdata
		 */
		if(cdataReplace) {
			String replacedFile = fileName + "_no_cdata.xml";
			try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
				try(BufferedWriter writer = new BufferedWriter(new FileWriter(replacedFile))) {
					String readLine = null;
					while((readLine = reader.readLine()) != null) {
						writer.write(readLine.replaceFirst("<\\!\\[CDATA\\[", "").replaceAll("\\]\\]>", ""));
						writer.newLine();
					}
				} catch(IOException e) {
					e.printStackTrace();
					fatal("cannot open file: " + replacedFile);
				}
			} catch(IOException e) {
				e.printStackTrace();
				fatal("cannot open file: " + fileName);
			}
		}
	}

	private static void writeRandomLog() {
		int len = rnd.nextInt(10);
		String log = RandomStringUtils.random(len, "aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ1234567890");
		int kind = rnd.nextInt(6);
		switch(kind) {
		case 0:
			logger.fatal(log);
			break;
		case 1:
			logger.error(log);
			break;
		case 2:
			logger.warn(log);
			break;
		case 3:
			logger.info(log);
			break;
		case 4:
			logger.debug(log);
			break;
		case 5:
			logger.trace(log);
			break;
		default:
			logger.info(log);
			break;
		}
	}

	private static void fatal(String msg) {
		System.err.println("[fatal]: " + msg);
		System.exit(1);
	}
}
