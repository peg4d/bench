## build requirement
 * jdk8
 * ant

## How to use


    $ ant clena && ant
    $ java -jar slog4j.jar -n 100 -o log.xml -r


## help

    $ java -jar slog4j.jar -h
